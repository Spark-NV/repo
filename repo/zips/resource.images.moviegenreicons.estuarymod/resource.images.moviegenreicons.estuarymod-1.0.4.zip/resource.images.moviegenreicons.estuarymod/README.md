## Movie Genres Icons for Estuary MOD V2


This addons allows to have icons for movies genres.


### • Changes : [Here](https://raw.githubusercontent.com/Guilouz/repository.guilouz/master/resource.images.moviegenreicons.estuarymod/changelog.txt)


### • Installation :

- In Kodi go to "Settings / Add-ons / Install from Zip file".
- Select downloaded ZIP file.
- Once installed, go to "Settings / Add-ons / Install from repository / Guilouz Repository / Look and feel / Image collections" and install Movie Genres Icons for Estuary MOD V2.
- Configure it in skin settings.

### • Download my Repository :

[ ![Download](http://i.imgur.com/L5Bov8X.png) ](https://github.com/Guilouz/repository.guilouz/raw/master/_repo/repository.guilouz/repository.guilouz-1.0.3.zip)

### • Donation :

If you like my work and would like to buy me a beer or a coffee, I would appreciate :)

[ ![Download](http://i.imgur.com/XRmqzTX.png) ](https://pledgie.com/campaigns/29797)